public class TrollFactory extends CharacterFactory{
    @Override
    public Character create() {
        return new Troll("bop",new KnifeBehavior());
    }
}
