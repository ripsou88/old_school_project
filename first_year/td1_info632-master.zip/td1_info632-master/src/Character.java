import java.util.Scanner;

public abstract class Character implements Observer{
    public String name;
    public int life;
    public WeaponBehavior weaponBehavior;

    public void fight(Character character) {
        while (this.life >0 && character.life>0){
            this.action(character);
            character.action(this);
        }
        if(this.life<character.life){
            Logger.getInstance().print(character.name+" gagne le combat!!!!");
        }
        if(this.life>character.life){
            Logger.getInstance().print(this.name+" gagne le combat!!!!");

        }
    };
    public void action(Character c){
        System.out.println(this.name+" veux tu attaquer(1) ou changer d'arme(2)?");
        Scanner sc = new Scanner(System.in);
        int choice = sc.nextInt();
        if (choice==1){
            int damage = this.weaponBehavior.useWeapon();
            c.life-=damage;
            Logger.getInstance().print(c.name+" perd "+damage+" point de vie!");
        }
        if(choice==2){
            System.out.println("1:hache 2:epee 3:arc 4:couteau");
            Scanner sc2 = new Scanner(System.in);
            int weaponChoice=sc.nextInt();
            if (weaponChoice==1){
                this.setWeaponBehavior(new AxeBehavior());
            }
            if(weaponChoice==2){
                this.setWeaponBehavior(new SwordBehavior());
            }
            if (weaponChoice==3){
                this.setWeaponBehavior(new BowAndArrowBehavior());
            }
            if (weaponChoice==4){
                this.setWeaponBehavior(new KnifeBehavior());
            }
            Logger.getInstance().print(this.name+" prend une "+this.weaponBehavior.toString());

        }
    }
    public Character(String name,WeaponBehavior weaponBehavior) {
        this.name=name;
        this.weaponBehavior = weaponBehavior;
    }

    public void setWeaponBehavior(WeaponBehavior w){
        this.weaponBehavior = w;
    }



    @Override
    public void update(String event) {
        System.out.println(this.name+" "+event);


    }}
