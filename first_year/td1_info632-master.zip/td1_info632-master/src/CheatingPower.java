public class CheatingPower extends MagicalPower{
    public CheatingPower(WeaponBehavior weaponBehavior) {
        super(weaponBehavior);
    }
    @Override
    public int useWeapon(){
        return 1000;
    }
}
