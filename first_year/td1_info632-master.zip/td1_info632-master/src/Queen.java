public class Queen extends Character{

    public Queen(String name, WeaponBehavior weaponBehavior) {
        super(name, weaponBehavior);
        this.life=35;
    }

    }
