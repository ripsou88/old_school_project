public class BowAndArrowBehavior implements WeaponBehavior{

    public int weaponWear = 50;

    @Override
    public int useWeapon() {
        if(this.weaponWear==0){
            return 0;
        }else {
            this.weaponWear-=1;
            return 3;
        }

    }
    @Override
    public String toString(){
        return "bow and arrow";
    }
}
