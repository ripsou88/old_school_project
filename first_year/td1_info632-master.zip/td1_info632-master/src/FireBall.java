public class FireBall extends MagicalPower{
    public FireBall(WeaponBehavior weaponBehavior) {
        super(weaponBehavior);
    }

    @Override
    public int useWeapon() {
        return super.useWeapon()+50;
    }
}
