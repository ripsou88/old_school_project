public class Troll extends Character{

    public Troll(String name, WeaponBehavior weaponBehavior) {
        super(name, weaponBehavior);
        this.life=80;
    }

    }
