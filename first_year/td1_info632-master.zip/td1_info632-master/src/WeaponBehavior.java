public interface WeaponBehavior {

    int useWeapon();
}
