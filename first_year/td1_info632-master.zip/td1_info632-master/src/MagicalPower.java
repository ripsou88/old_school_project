public abstract class MagicalPower implements WeaponBehavior{

    WeaponBehavior weaponBehavior;

    public MagicalPower(WeaponBehavior weaponBehavior) {
        this.weaponBehavior = weaponBehavior;
    }

    @Override
    public int useWeapon() {
        return weaponBehavior.useWeapon();
    }

}
