public class KingFactory extends CharacterFactory{


    @Override
    public Character create() {
        return new King("Mario",null);
    }
}
