import java.util.ArrayList;

public class Jeu {
    public static void main(String[] args) {
        Castle castle = new Castle(new ArrayList<Character>());


        Queen arthur = new Queen("arthur",new CheatingPower(new KnifeBehavior()));
        King adam = new King("adam",new AxeBehavior());
        castle.addCharacter(arthur);
        castle.addCharacter(adam);
        TrollFactory cabane=new TrollFactory();
        Character troll1=cabane.create();

        Duck bobby=new Duck();
        DuckAdaptater boby = new DuckAdaptater("bobby", bobby);


        castle.attackAllert();


        adam.setWeaponBehavior(new FireBall(new KnifeBehavior()) );

    }
}