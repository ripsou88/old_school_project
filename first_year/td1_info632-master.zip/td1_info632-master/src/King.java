public class King extends Character{


    public King(String name, WeaponBehavior weaponBehavior) {
        super(name, weaponBehavior);
        this.life=40;
    }


    }
