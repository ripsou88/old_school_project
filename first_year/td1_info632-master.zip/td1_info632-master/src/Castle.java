import java.util.ArrayList;

public class Castle {
    ArrayList<Character> listCharacter;

    public Castle(ArrayList<Character> listCharacter) {
        this.listCharacter = listCharacter;
    }
    public void addCharacter(Character c){
        listCharacter.add(c);
    }

    public void removeCharacter(Character c){
        listCharacter.remove(c);
    }
    public void attackAllert(){
        for(Character c:listCharacter){
            c.update("le chateau est attaqué!!");
        }
    }
}
