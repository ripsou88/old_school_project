public abstract class CharacterFactory {

    public abstract Character create();
}
