public class SwordBehavior implements WeaponBehavior{
    public int weaponWear = 50;

    @Override
    public int useWeapon() {
        if(this.weaponWear==0){
            return 0;
        }else {
            this.weaponWear-=6;
            return 7;
        }

    }
    @Override
    public String toString(){
        return "Sword";
    }
}
