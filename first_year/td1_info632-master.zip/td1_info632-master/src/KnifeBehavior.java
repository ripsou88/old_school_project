public class KnifeBehavior implements WeaponBehavior{
    public int weaponWear = 50;
    @Override
    public int useWeapon() {
        if(this.weaponWear==0){
            return 0;
        }else {
            this.weaponWear-=3;
            return 3;
        }

    }
    @Override
    public String toString(){
        return "knife";
    }
}
