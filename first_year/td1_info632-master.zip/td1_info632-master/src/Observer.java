public interface Observer {
    public default void update(String event){}
}
