public class AxeBehavior implements WeaponBehavior{
    public int weaponWear = 50;

    @Override
    public int useWeapon() {
        if(this.weaponWear==0){
            return 0;
        }else {
            this.weaponWear-=10;
            return 10;
        }
    }
    @Override
    public String toString(){
        return "Axe";
    }
}
