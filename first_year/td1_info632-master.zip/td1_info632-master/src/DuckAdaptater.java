public class DuckAdaptater extends Character{
    private Duck duck;


    public DuckAdaptater(String name,Duck duck) {
        super(name, null);
        this.life=1;
        this.duck=duck;
    }

    @Override
    public void fight(Character character) {
        duck.fight();
    }

    @Override
    public void action(Character c) {
        fight(c);


    }



}
