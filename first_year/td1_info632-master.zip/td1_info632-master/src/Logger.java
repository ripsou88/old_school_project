public class Logger {
    private static Logger logger;

    private Logger() {
    }

    public static Logger getInstance(){
        if(logger==null){
            Logger.logger=new Logger();
        }
        return logger;

    }
    public void print(String text){
        System.out.println(text);
    }
}
