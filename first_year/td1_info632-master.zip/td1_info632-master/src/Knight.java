public class Knight extends Character{

    public Knight(String name, WeaponBehavior weaponBehavior) {
        super(name, weaponBehavior);
        this.life=60;
    }


    }
