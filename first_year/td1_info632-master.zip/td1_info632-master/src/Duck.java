public class Duck {
    public void fight(){
        Logger.getInstance().print("le canard fuit en courant");
    }
}
