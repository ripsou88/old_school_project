public interface ShuffleStrategy {
    int shuffle(String word, int nbReducers);
}
